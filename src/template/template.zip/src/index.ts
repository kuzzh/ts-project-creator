document.addEventListener('DOMContentLoaded', () => {
    const projectNameEl = document.getElementById('projectName') as HTMLSpanElement;
    
    projectNameEl.innerText = '{ProjectName}';
  });